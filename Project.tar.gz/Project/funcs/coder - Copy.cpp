#include <iostream>
#include <math.h>
#include <string.h>
using namespace std;
void coder (char *a,int *F);
void decoder (int *a,char *F);
int main()
{
	char a[14],aa[14];
	int tmp[14];
	a[0]='S';
	a[1]='a';
	a[2]='l';
	a[3]='a';
	a[4]='m';
	a[5]='.';
	a[6]='C';
	a[7]='h';
	a[8]='e';
	a[9]='t';
	a[10]='o';
	a[11]='r';
	a[12]='i';
	a[13]='\0';
	coder (a,tmp);
	cout<<"CODE : ";
	for (int i=0;i<14;i++)
        cout<<tmp[i];
    cout<<endl<<"DECODE : ";
    decoder (tmp,aa);
    for (int j=0;j<13;j++)
        cout<<aa[j];
}
void coder (char *a,int *F)
{
	int length,c;
	length=strlen (a);
	int b[length+1];
	b[0]=length;
	b[1]=a[0]-1;
	for (length;length>1;length--)
	{
		b[length]=a[length-1]+a[length-2]-1;
	}
	c=b[0];
	for (c;c>=0;c--)
	{
	    F[c]=b[c];
	}
}
void decoder (int *a,char *F)
{
	int d,c,length,t=1;
	length=a[0];
	d=length;
	a[0]=0;
	char b[length+1];
	b[length]='\0';
	c=length;
	for(c;c>=1;c--)
	{
		a[c]+=1;
	}
	b[0]=a[1];
	for (t;t<=length;t++)
	{
		b[t]=a[t+1]-a[t];
		a[t+1]=b[t];
	}
	for (d;d>=0;d--)
	{
	    F[d]=b[d];
	}
}
