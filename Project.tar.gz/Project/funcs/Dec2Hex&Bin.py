#decimal to binary & hex
while 1:
    a=input("Enter Decimal Num:")
    d=a
    b=""
    c=""
    while (a>0):
        b=str((a%2))+b
        a=a/2
    while (d>0):
        e=d%16
        if (e<10):
            c=str(e)+c
        if (e>=10):
            if e==10:
                c="A"+c
            if e==11:
                c="B"+c
            if e==12:
                c="C"+c
            if e==13:
                c="D"+c
            if e==14:
                c="E"+c
            if e==15:
                c="F"+c
        d=d/16
    print ("Hex:",c)
    print ("Binary:",b)
    print ("-----------")
