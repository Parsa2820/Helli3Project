#include <iostream>
#include <math.h>
#include <string.h>
using namespace std;
void coder (char *a,int *F);
void decoder (int *a,char *F);
int main()
{
    cout<<endl<<endl;
	char a[15],aa[15];
	int tmp[15];
	a[0]='A';
	a[1]='l';
	a[2]='l';
	a[3]='m';
	a[4]='e';
	a[5]=' ';
	a[6]='H';
	a[7]='e';
	a[8]='l';
	a[9]='l';
	a[10]='i';
	a[11]=' ';
	a[12]='3';
	a[13]=' ';
	a[14]='\0';
	coder (a,tmp);
	cout<<"CODE : ";
	for (int i=0;i<15;i++)
        cout<<tmp[i];
    cout<<endl<<endl<<endl<<"DECODE : ";
    decoder (tmp,aa);
    for (int j=0;j<14;j++)
        cout<<aa[j];
    cout<<endl<<endl;
}
void coder (char *a,int *F)
{
	int length,c;
	length=strlen (a);
	int b[length+1];
	b[0]=length;
	b[1]=a[0]-1;
	for (length;length>1;length--)
	{
		b[length]=a[length-1]+a[length-2]-1;
	}
	c=b[0];
	for (c;c>=0;c--)
	{
	    F[c]=b[c];
	}
}
void decoder (int *a,char *F)
{
	int d,c,length,t=1;
	length=a[0];
	d=length;
	a[0]=0;
	char b[length+1];
	b[length]='\0';
	c=length;
	for(c;c>=1;c--)
	{
		a[c]+=1;
	}
	b[0]=a[1];
	for (t;t<=length;t++)
	{
		b[t]=a[t+1]-a[t];
		a[t+1]=b[t];
	}
	for (d;d>=0;d--)
	{
	    F[d]=b[d];
	}
}
