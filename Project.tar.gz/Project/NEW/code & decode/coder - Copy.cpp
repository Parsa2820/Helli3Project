#include <iostream>
#include <math.h>
#include <string.h>
using namespace std;
int* coder (char *a);
int* decoder (char *a);
int main()
{
	char a[2];
	int *tmp;
	a[0]='a';
	a[1]='b';
	tmp = coder (a);
	cout<<tmp[0]<<"|"<<tmp[1];
		
}
int* coder (char *a)
{	
	int length;
	length=strlen (a);
	int b[length+1];
	for (length;length>0;length--)
	{
		b[length]=a[length]+a[length-1]-1;
	}
	b[0]=a[0]-1;
	return b;
}
/*
int* decoder (int *a)
{
	int c,length;
	length=strlen (a);
	char b[length+1];
	c=length;
	for(c;c>=0;c--)
	{
		a[c]-=1;
	}
	for (length;length>0;length--)
	{
		b[length]=a[length]-a[length-1];
	}
	b[0]=a[0];
	cout<<b[0];
}
*/
